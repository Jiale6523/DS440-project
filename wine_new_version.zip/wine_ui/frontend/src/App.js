import React, { useState, useEffect } from 'react';
import { TextField, Button, Paper, Typography, Container, Grid, Slider, Box, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Divider } from '@mui/material';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import './App.css';

const theme = createTheme({
  palette: {
    primary: {
      main: '#8b0000',
    },
    secondary: {
      main: '#722f37',
    },
  },
});

const features = [
  { name: 'fixed_acidity', label: 'Fixed Acidity', min: 4, max: 16, step: 0.1 },
  { name: 'volatile_acidity', label: 'Volatile Acidity', min: 0, max: 1.5, step: 0.01 },
  { name: 'citric_acid', label: 'Citric Acid', min: 0, max: 1, step: 0.01 },
  { name: 'residual_sugar', label: 'Residual Sugar', min: 0, max: 16, step: 0.1 },
  { name: 'chlorides', label: 'Chlorides', min: 0, max: 0.5, step: 0.001 },
  { name: 'free_sulfur_dioxide', label: 'Free Sulfur Dioxide', min: 1, max: 72, step: 1 },
  { name: 'total_sulfur_dioxide', label: 'Total Sulfur Dioxide', min: 6, max: 289, step: 1 },
  { name: 'density', label: 'Density', min: 0.99, max: 1.01, step: 0.0001 },
  { name: 'pH', label: 'pH', min: 2.7, max: 4.0, step: 0.01 },
  { name: 'sulphates', label: 'Sulphates', min: 0.3, max: 2.0, step: 0.01 },
  { name: 'alcohol', label: 'Alcohol', min: 8, max: 15, step: 0.1 },
];

// Map backend feature names to frontend feature names
const featureNameMapping = {
  'fixed acidity': 'fixed_acidity',
  'volatile acidity': 'volatile_acidity',
  'citric acid': 'citric_acid',
  'residual sugar': 'residual_sugar',
  'chlorides': 'chlorides',
  'free sulfur dioxide': 'free_sulfur_dioxide',
  'total sulfur dioxide': 'total_sulfur_dioxide',
  'density': 'density',
  'pH': 'pH',
  'sulphates': 'sulphates',
  'alcohol': 'alcohol'
};

function App() {
  const [values, setValues] = useState({});
  const [prediction, setPrediction] = useState(null);
  const [error, setError] = useState(null);
  const [featureImportance, setFeatureImportance] = useState([]);
  const [samples, setSamples] = useState({});
  const [loading, setLoading] = useState(false);

  // Initialize default values
  useEffect(() => {
    const defaultValues = {};
    features.forEach(feature => {
      defaultValues[feature.name] = feature.min;
    });
    setValues(defaultValues);
  }, []);

  const handleSubmit = async () => {
    setError(null);
    setLoading(true);
    try {
      const response = await fetch('http://localhost:5000/predict', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(values),
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Prediction request failed');
      }
      const data = await response.json();
      setPrediction(data.prediction);
      setFeatureImportance(data.feature_importance || []);
      setSamples(data.samples || {});
    } catch (error) {
      console.error('Error:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (name, value) => {
    setValues(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  // Calculate the width of feature importance bars
  const getBarWidth = (importance) => {
    const maxImportance = featureImportance.length > 0 
      ? Math.max(...featureImportance.map(item => item[1])) 
      : 0;
    return (importance / maxImportance) * 100;
  };

  // Get feature label from name
  const getFeatureLabel = (name) => {
    const feature = features.find(f => f.name === featureNameMapping[name] || f.name === name);
    return feature ? feature.label : name;
  };

  // Format value based on feature type
  const formatValue = (name, value) => {
    const feature = features.find(f => f.name === featureNameMapping[name] || f.name === name);
    if (!feature) return value;
    
    return feature.step < 0.1 ? value.toFixed(3) : value.toFixed(1);
  };

  // Load a sample into the sliders
  const loadSample = (sample) => {
    if (!sample) return;
    
    const newValues = { ...values };
    
    // Handle different sample data structures
    if (sample.features) {
      // Current prediction format
      Object.entries(sample.features).forEach(([name, value]) => {
        const frontendName = featureNameMapping[name] || name;
        newValues[frontendName] = value;
      });
    } else {
      // Sample from backend format
      Object.entries(sample).forEach(([name, value]) => {
        if (name !== 'quality') {
          const frontendName = featureNameMapping[name] || name;
          newValues[frontendName] = value;
        }
      });
    }
    
    setValues(newValues);
  };

  return (
    <ThemeProvider theme={theme}>
      <Container maxWidth="md" sx={{ py: 4 }}>
        <Paper elevation={3} sx={{ p: 4, borderRadius: 2 }}>
          <Typography variant="h4" gutterBottom align="center" color="primary">
            Wine Quality Prediction
          </Typography>
          
          <Grid container spacing={3}>
            {features.map((feature) => (
              <Grid item xs={12} sm={6} key={feature.name}>
                <Typography gutterBottom>
                  {feature.label}
                </Typography>
                <Slider
                  value={values[feature.name] || feature.min}
                  onChange={(_, value) => handleChange(feature.name, value)}
                  min={feature.min}
                  max={feature.max}
                  step={feature.step}
                  valueLabelDisplay="auto"
                />
                <Typography variant="caption" color="text.secondary">
                  {values[feature.name]?.toFixed(feature.step < 0.1 ? 3 : 1) || feature.min}
                </Typography>
              </Grid>
            ))}
          </Grid>

          <Button
            variant="contained"
            color="primary"
            fullWidth
            sx={{ mt: 4 }}
            onClick={handleSubmit}
            disabled={loading}
          >
            {loading ? 'Predicting...' : 'Predict Quality'}
          </Button>

          {error && (
            <Typography 
              color="error" 
              align="center" 
              sx={{ mt: 2 }}
            >
              {error}
            </Typography>
          )}

          {prediction !== null && !error && (
            <Box sx={{ mt: 4 }}>
              <Typography variant="h5" align="center" gutterBottom>
                Predicted Quality: {prediction} / 10
              </Typography>
              
              {/* Sample Comparison Section */}
              {Object.keys(samples).length > 0 && (
                <Box sx={{ mt: 4 }}>
                  <Typography variant="h6" gutterBottom>
                    Quality Comparison
                  </Typography>
                  
                  <TableContainer component={Paper} sx={{ mt: 2, mb: 4 }}>
                    <Table size="small">
                      <TableHead>
                        <TableRow sx={{ backgroundColor: 'rgba(139, 0, 0, 0.1)' }}>
                          <TableCell>Feature</TableCell>
                          {samples.lower && (
                            <TableCell align="center">
                              Quality {samples.lower.quality}
                              <Button 
                                size="small" 
                                variant="outlined" 
                                sx={{ ml: 1 }}
                                onClick={() => loadSample(samples.lower)}
                              >
                                Load
                              </Button>
                            </TableCell>
                          )}
                          <TableCell align="center" sx={{ fontWeight: 'bold' }}>
                            Your Wine (Quality {prediction})
                          </TableCell>
                          {samples.higher && (
                            <TableCell align="center">
                              Quality {samples.higher.quality}
                              <Button 
                                size="small" 
                                variant="outlined" 
                                sx={{ ml: 1 }}
                                onClick={() => loadSample(samples.higher)}
                              >
                                Load
                              </Button>
                            </TableCell>
                          )}
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {featureImportance.map(([featureName, importance]) => {
                          const frontendName = featureNameMapping[featureName] || featureName;
                          return (
                            <TableRow key={featureName} hover>
                              <TableCell component="th" scope="row">
                                {getFeatureLabel(featureName)}
                              </TableCell>
                              
                              {samples.lower && (
                                <TableCell align="center">
                                  {formatValue(featureName, samples.lower[featureName])}
                                </TableCell>
                              )}
                              
                              <TableCell align="center" sx={{ fontWeight: 'bold' }}>
                                {formatValue(frontendName, values[frontendName])}
                              </TableCell>
                              
                              {samples.higher && (
                                <TableCell align="center">
                                  {formatValue(featureName, samples.higher[featureName])}
                                </TableCell>
                              )}
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Box>
              )}
              
              {/* Feature Importance Section */}
              {featureImportance.length > 0 && (
                <Box sx={{ mt: 4 }}>
                  <Typography variant="h6" gutterBottom>
                    Feature Importance
                  </Typography>
                  <Box sx={{ mt: 2 }}>
                    {featureImportance.map((item, index) => (
                      <Box key={index} sx={{ mb: 1 }}>
                        <Grid container alignItems="center">
                          <Grid item xs={3}>
                            <Typography variant="body2">
                              {getFeatureLabel(item[0])}
                            </Typography>
                          </Grid>
                          <Grid item xs={8}>
                            <Box 
                              sx={{ 
                                height: 10, 
                                width: `${getBarWidth(item[1])}%`, 
                                bgcolor: 'primary.main',
                                borderRadius: 1
                              }} 
                            />
                          </Grid>
                          <Grid item xs={1}>
                            <Typography variant="caption">
                              {(item[1] * 100).toFixed(1)}%
                            </Typography>
                          </Grid>
                        </Grid>
                      </Box>
                    ))}
                  </Box>
                </Box>
              )}
            </Box>
          )}
        </Paper>
      </Container>
    </ThemeProvider>
  );
}

export default App; 