from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle
import json
import logging
import pandas as pd
import numpy as np

app = Flask(__name__)
CORS(app)

try:
    # Load model and feature importance
    with open('models/voting_classifier_model.pkl', 'rb') as f:
        model = pickle.load(f)

    with open('models/feature_importance.json', 'r') as f:
        feature_importance = json.load(f)
        
    # Load sample data for different quality levels
    with open('models/wine_quality_data.json', 'r') as f:
        wine_samples = json.load(f)
        # Create a dictionary with quality as key for easier access
        wine_samples_by_quality = {item['quality']: item for item in wine_samples}
except Exception as e:
    logging.error(f"Model loading failed: {str(e)}")
    model = None
    feature_importance = None
    wine_samples_by_quality = {}

@app.route('/predict', methods=['POST'])
def predict():
    if model is None:
        return jsonify({
            'error': 'Model loading failed, please ensure model file exists and version is compatible'
        }), 500
        
    try:
        data = request.json
        
        feature_names = [
            'fixed acidity', 
            'volatile acidity', 
            'citric acid', 
            'residual sugar', 
            'chlorides', 
            'free sulfur dioxide', 
            'total sulfur dioxide', 
            'density', 
            'pH', 
            'sulphates', 
            'alcohol'
        ]
        
        feature_values = [
            data['fixed_acidity'],
            data['volatile_acidity'],
            data['citric_acid'],
            data['residual_sugar'],
            data['chlorides'],
            data['free_sulfur_dioxide'],
            data['total_sulfur_dioxide'],
            data['density'],
            data['pH'],
            data['sulphates'],
            data['alcohol']
        ]
        
        input_df = pd.DataFrame([feature_values], columns=feature_names)
        
        # Make prediction
        prediction = int(model.predict(input_df)[0])
        
        # Get sample data for adjacent quality levels
        samples = {}
        min_quality = 3
        max_quality = 8
        
        # Add current prediction's features
        samples['current'] = {
            'quality': prediction,
            'features': {name: value for name, value in zip(feature_names, feature_values)}
        }
        
        # Add lower quality sample if available
        if prediction > min_quality and (prediction - 1) in wine_samples_by_quality:
            samples['lower'] = wine_samples_by_quality[prediction - 1]
            
        # Add higher quality sample if available
        if prediction < max_quality and (prediction + 1) in wine_samples_by_quality:
            samples['higher'] = wine_samples_by_quality[prediction + 1]
        
        return jsonify({
            'prediction': prediction,
            'feature_importance': feature_importance,
            'samples': samples
        })
    except Exception as e:
        logging.error(f"Prediction error: {str(e)}")
        return jsonify({
            'error': f'Prediction failed: {str(e)}'
        }), 500

if __name__ == '__main__':
    app.run(debug=True) 